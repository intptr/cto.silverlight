﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;

namespace Cto.Silverilght.ValueConverters
{
	public class DoubleFormatConverter : IValueConverter
	{
		private const int defaultFractionDigits = 2;

		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			if (value == null)
				return string.Empty;

			double doubleValue = System.Convert.ToDouble(value);

			if (doubleValue == double.MinValue)
			{
				return string.Empty;
			}
			else
			{
				int fractionDigits = defaultFractionDigits;

				if (parameter != null)
				{
					int decimals;
					if (int.TryParse(parameter.ToString(), out decimals))
						fractionDigits = decimals;
				}

				return Math.Round(doubleValue, fractionDigits).ToString();
			}
		}

		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
