﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.IO;
using System.Xml.Linq;

using Microsoft.Maps.MapControl;

using ServiceReference = Cto.Silverilght.ServiceReference3;
using System.Collections.Generic;
using System.ComponentModel;
using Cto.Silverilght.Classes;

namespace Cto.Silverilght.ViewModels
{
	public class MainWindowViewModel : ViewModelBase
	{
		public ObservableCollection<LandMark> allMapItems = new ObservableCollection<LandMark>();

		ServiceReference.LandMarkServiceClient client = new ServiceReference.LandMarkServiceClient();

		public MainWindowViewModel()
		{
			this.Cities = new List<City>()
			{
				new City() { DisplayName = "Sofia", Location = new Location(42.678586, 23.366032) },
				new City() { DisplayName = "Plovdiv", Location = new Location(42.15, 24.75) },
			};

			this.CurrentCity = this.Cities[0];

			this.MapLocation = this.CurrentCity.Location;

			this.CategoriesFilter = new CategorySelectionCollection()
			{
				new CategorySelection() { IsSelected = true, Category = Category.All },
				new CategorySelection() { IsSelected = true, Category = Category.FoodAndTravel },
				new CategorySelection() { IsSelected = true, Category = Category.Entertainment },
				new CategorySelection() { IsSelected = true, Category = Category.Services },
				new CategorySelection() { IsSelected = true, Category = Category.Shopping },
				new CategorySelection() { IsSelected = true, Category = Category.HealthAndBeauty }
			};

			foreach (var item in CategoriesFilter)
			{
				item.PropertyChanged += (s, e) =>
				{
					CategorySelection selectedCategory = ((CategorySelection)s);

					if (selectedCategory.Category == Category.All)
					{
						foreach (var category in CategoriesFilter)
						{
							if (category.Category == Category.All)
								continue;

							category.IsSelected = selectedCategory.IsSelected;
						}
					}
					else
					{
						this.ReloadFilteredMarks();
					}
				};
			}

			this.MapItems = new ObservableCollection<LandMark>();

			this.allMapItems = new ObservableCollection<LandMark>() 
			{ 
			    new LandMark() { RealValue = 100, BuyValue = 50, Category = Category.Entertainment, GeoLocation = new Location(42.678586, 23.366032), Title = "test1", ImageURI = new Uri("http://takova.com/logos/diesel.png") },
			    new LandMark() { RealValue = 80, BuyValue = 20, Category = Category.FoodAndTravel, GeoLocation = new Location(42.678618, 23.354616), Title = "test2", ImageURI = new Uri("http://cdn1.iconfinder.com/data/icons/brightmix/128/monotone_fork_spoon_dinner_eat_restaurant.png") } 
			};


			this.ReloadFilteredMarks();			
		}

		private Location mapLocation = null;
		public Location MapLocation
		{
			get
			{
				return this.mapLocation;
			}
			set
			{
				this.mapLocation = value;
				base.OnPropertyChanged("MapLocation");
			}
		}

		private bool isRefreshNeeded = false;
		public bool IsRefreshNeeded
		{
			get
			{
				return this.isRefreshNeeded;
			}
			set
			{
				this.isRefreshNeeded = value;
				base.OnPropertyChanged("IsRefreshNeeded");
			}
		}

		public List<City> Cities
		{
			get;
			set;
		}

		private City currentCity = null;
		public City CurrentCity
		{
			get
			{
				return this.currentCity;
			}
			set
			{
				this.currentCity = value;
				base.OnPropertyChanged("CurrentCity");
			}
		}

		public ObservableCollection<LandMark> MapItems
		{
			get;
			set;
		}

		private double selectedMinDiscountValue = 50;
		public double SelectedMinDiscountValue
		{
			get
			{
				return this.selectedMinDiscountValue;
			}
			set
			{
				this.selectedMinDiscountValue = value;

				base.OnPropertyChanged("SelectedMinDiscountValue");

				this.ReloadFilteredMarks();
			}
		}

		public class CategorySelectionCollection : List<CategorySelection>
		{
			public bool IsCategorySelected(long categoryId)
			{
				foreach (var item in this)
				{
					if ((long)item.Category != categoryId)
						continue;

					return item.IsSelected;
				}

				return false;
			}
		}

		public CategorySelectionCollection CategoriesFilter
		{
			get;
			set;
		}

		private TimeLeftFilterTypes selectedTimeLeftFilterType = TimeLeftFilterTypes.Week;
		public TimeLeftFilterTypes SelectedTimeLeftFilterType
		{
			get
			{
				return this.selectedTimeLeftFilterType;
			}
			set
			{
				this.selectedTimeLeftFilterType = value;
			}
		}

		private void ReloadFilteredMarks()
		{
			this.MapItems.Clear();

			foreach (var item in this.allMapItems)
			{
				if (IsMatchingCurrentFilters(item))
					this.MapItems.Add(item);
			}

			base.OnPropertyChanged("MapItems");
		}

		private bool IsMatchingCurrentFilters(LandMark item)
		{
			if (item.GetDiscountValue() < this.SelectedMinDiscountValue)
				return false;

			if (!this.CategoriesFilter.IsCategorySelected((long)item.Category))
				return false;
		
			return true;
		}

		private DelegateCommand getMarksByLocationCommand = null;
		public ICommand GetMarksByLocationCommand
		{
			get
			{
				if (this.getMarksByLocationCommand == null)
				{
					this.getMarksByLocationCommand = new DelegateCommand(
						param =>
						{
							client.GetMarksByLocationAsync(new ServiceReference.RequestProperties()
							{
								guid = new Guid("425C9427-ACF0-4217-8575-001D1E540448"),
								latitude = (int)this.MapLocation.Latitude * 1000000,
								longitude = (int)this.MapLocation.Longitude * 1000000,
								zoomLevel = 18,
								languageId = 1,
								categories = "1,2",
								userGUID = new Guid("425C9427-ACF0-4217-8575-001D1E540448")
							});
						},
						param =>
						{
							return true;
						});
				}

				return this.getMarksByLocationCommand;
			}
		}

		public class CategorySelection : ViewModelBase
		{
			private bool isSelected = true;
			public bool IsSelected
			{
				get
				{
					return this.isSelected;
				}
				set
				{
					this.isSelected = value;
					base.OnPropertyChanged("IsSelected");
				}
			}

			public Category Category
			{
				get;
				set;
			}
		}

		public enum Category
		{
			All				= 0,
			FoodAndTravel	= 1,
			Entertainment	= 2,
			Services		= 3,
			Shopping		= 4,
			HealthAndBeauty = 5
		}

		public enum TimeLeftFilterTypes
		{
			Month	= 0, 
			Week	= 1,
			Day		= 2
		}

		public class City
		{
			public string DisplayName
			{
				get;
				set;
			}

			public Location Location
			{
				get;
				set;
			}
		}
		
		public class LandMark
		{
			public string Title
			{
				get;
				set;
			}

			public Location GeoLocation
			{
				get;
				set;
			}

			public Uri ImageURI
			{
				get;
				set;
			}

			public Category Category
			{
				get;
				set;
			}

			public decimal RealValue
			{
				get;
				set;
			}

			public decimal BuyValue
			{
				get;
				set;
			}
		}
	}

	public static class Extensions
	{
		public static double GetDiscountValue(this Cto.Silverilght.ViewModels.MainWindowViewModel.LandMark mark)
		{
			if (mark.RealValue == 0)
				return 0;

			return (double)Math.Round(mark.BuyValue / mark.RealValue * 100, 0);
		}
	}
}
