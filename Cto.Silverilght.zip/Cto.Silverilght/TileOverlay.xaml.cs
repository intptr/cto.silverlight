﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Maps.MapControl;
using System.Collections.ObjectModel;
using System;
using System.Net;
using System.IO;
using System.Xml.Linq;
using BingCustomPushpins;
using System.Windows.Media;

namespace Cto.Silverilght
{
    public partial class TileOverlay : UserControl
    {
        MapTileLayer tileLayer;
        private double tileOpacity = 1.0;

        public TileOverlay()
        {    
            InitializeComponent();

			this.MapItems = new ObservableCollection<LandMark>() 
			{ 
			    new LandMark() { GeoLocation = new Location(42.678586, 23.366032) },
				new LandMark() { GeoLocation = new Location(42.678618, 23.354616) } 
			};

			//this.DataContext = this;

			this.setLocation();
        }



		public ObservableCollection<LandMark> MapItems
		{
			get;
			set;
		}

		public class LandMark
		{
			public Location GeoLocation
			{
				get; set;
			}

			public string geoPoint;
			public string GeoPoint
			{
				get
				{
					return this.geoPoint;
				}
				set
				{
					this.geoPoint = value;
				}
			}
		}

		private void setLocation()
		{
			Uri serviceUri = new Uri("http://silverlightmaps.org/services/geolocation_service.php");

			// Create a web client to load the document
			WebClient client = new WebClient();
			client.OpenReadCompleted += new OpenReadCompletedEventHandler(client_OpenReadCompleted);
			client.OpenReadAsync(serviceUri);
		}

		public void client_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
		{
			if (e.Error != null)
			{
				// Do nothing
				return;
			}
			using (Stream s = e.Result)
			{
				// Load the XML stream into the XDocument
				XDocument doc = XDocument.Load(s);
				XElement location = doc.Root;

				// Grab the latitude and longitude
				String latitude = location.Element("latitude").Value;
				String longitude = location.Element("longitude").Value;

				// Center the map over the coordinates
				MapTileOverlay.Center = new Location(Double.Parse(latitude), Double.Parse(longitude));
			}
		}

        private void AddTerrainTileOverlay()
        {
            // The bounding rectangle that the tile overlay can be placed within.

			foreach (var item in this.MapItems)
			{
				LocationRect boundingRect = new LocationRect(
					item.GeoLocation, 1, 1);

			    // Creates a new map layer to add the tile overlay to.
			    tileLayer = new MapTileLayer();

			    // The source of the overlay.
			    LocationRectTileSource tileSource = new LocationRectTileSource();
			    tileSource.UriFormat = "http://www.microsoft.com/maps/isdk/ajax/layers/lidar/{quadkey}.png";
			    // The zoom range that the tile overlay is visibile within
			    tileSource.ZoomRange = new Range<double>(10, 18);
			    // The bounding rectangle area that the tile overaly is valid in.
			    tileSource.BoundingRectangle = boundingRect;


			    // Adds the tile overlay to the map layer
			    tileLayer.TileSources.Add(tileSource);

			    // Adds the map layer to the map
			    if (!MapTileOverlay.Children.Contains(tileLayer))
			    {
			        MapTileOverlay.Children.Add(tileLayer);
			    }
			    tileLayer.Opacity = tileOpacity;
			}
        }

		private void AddNewTileLayer()
		{
			//var customTileLayer = new MapTileLayer();

			//// Define the Bounding Rectangle 
			//LocationRect boundingRect = new LocationRect(
			//    new Location(42.678586, 23.366032),
			//    new Location(42.678618, 23.354616)
			//);

			//// Create a LocationRectTileSource 
			//LocationRectTileSource customTileSource = new LocationRectTileSource();

			//// Set the Uri for the custom Map Imagery Tiles 
			//customTileSource.UriFormat = "http://dev.live.com/virtualearth/sdk/layers/lidar/{0}.png";

			//// Set the Min and Max Zoom Levels that the imagery is to be visible within 
			//customTileSource.ZoomRange = new Range<double>(10, 18);

			//// The bounding rectangle area that the tile overaly is valid in. 
			//customTileSource.BoundingRectangle = boundingRect;

			//// Add the Tile Source to the Tile Layer 
			//customTileLayer.TileSources.Add(customTileSource);

			//// Set the Tile Layer Opacity to a desired value 
			//customTileLayer.Opacity = 0.7;

			//MapTileOverlay.Children.Add(customTileLayer);

			foreach (var item in this.MapItems)
			{
				MapTileOverlay.Children.Add(new Pushpin() { Location = item.GeoLocation });
			}
		}

        private void btnAddTileLayer_Click(object sender, RoutedEventArgs e)
        {
			foreach (var item in this.MapItems)
			{
				MapPolygon polygon = new MapPolygon();
				polygon.Fill = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Red);
				polygon.Stroke = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Yellow);
				polygon.StrokeThickness = 5;
				polygon.Opacity = 0.7;
				//polygon.con
				polygon.Locations = new LocationCollection() { 
								item.GeoLocation,
								item.GeoLocation,
								item.GeoLocation,
								item.GeoLocation};

				MapTileOverlay.Children.Add(polygon);

				// Adds the tile overlay on the map, if it doesn't already exist.
				if (tileLayer != null)
				{
					if (!MapTileOverlay.Children.Contains(tileLayer))
					{
						MapTileOverlay.Children.Add(tileLayer);
					}
				}
				else
				{
					//AddTerrainTileOverlay();
				}
			}
			
        }

        private void btnRemoveTileLayer_Click(object sender, RoutedEventArgs e)
        {
			this.AddCustomPushpin();

			//this.AddNewTileLayer();
            // Removes the tile overlay if it has been added to the map.
			//if (MapTileOverlay.Children.Contains(tileLayer))
			//{
			//    MapTileOverlay.Children.Remove(tileLayer);
			//}
        }

		void AddCustomPushpin()
		{
			//Add shape layer to map
			MapLayer pinLayer = new MapLayer();
			this.MapTileOverlay.Children.Add(pinLayer);

			/**************************************
			 * Example of Icon Pushpin
			 **************************************/

			//Create a custom pushpin specification
			CustomIconSpecification iconSpec = new CustomIconSpecification()
			{
				IconUri = new Uri("customPin.png", UriKind.Relative),
				Width = 17,
				Height = 30,
				IconOffset = new Point(-8.5, -30),
				TextContent = "1",
				TextOffet = new Point(-8.5, -45)
			};

			foreach (var item in this.MapItems)
			{
				//Create custom pushpin
				//CustomPushpin pin = new CustomPushpin()
				//{
				//    IconSpecification = iconSpec,
				//    Location = item.GeoLocation
				//};

				////Add pushpin to layer
				//pinLayer.AddChild(pin);


				/**************************************
				 * Example of Circle Pushpin
				 **************************************/

				//Create a custom pushpin specification
				CustomIconSpecification iconSpec2 = new CustomIconSpecification()
				{
					Icon = PushpinTools.CreateImagePushpin(new Uri("http://takova.com/logos/diesel.png"), 60, 60, new Point(-10, -10)),
					Width = 20,
					Height = 20,
					IconOffset = new Point(-10, -10),
					TextContent = "Deals",
					TextOffet = new Point(-10, -10)

					//Icon = PushpinTools.CreateCirclePushpin(10, new SolidColorBrush(Colors.Red), new SolidColorBrush(Colors.Blue)),
					//Width = 20,
					//Height = 20,
					//IconOffset = new Point(-10, -10),
					//TextContent = "1",
					//TextOffet = new Point(-10, -10)
				};

				//Create custom pushpin
				CustomPushpin circlePin = new CustomPushpin()
				{
					IconSpecification = iconSpec2,
					Location = item.GeoLocation
				};

				circlePin.MouseLeftButtonDown += new System.Windows.Input.MouseButtonEventHandler(circlePin_MouseLeftButtonDown);
					

				//Add pushpin to layer
				pinLayer.AddChild(circlePin);
			}

		}

		void circlePin_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			
		}

    }
}