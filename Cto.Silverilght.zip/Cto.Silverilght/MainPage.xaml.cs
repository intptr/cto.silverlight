﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Xml.Linq;
using System.ComponentModel;

using Microsoft.Maps.MapControl;

using BingCustomPushpins;

using Cto.Silverilght.ViewModels;


namespace Cto.Silverilght
{
	public partial class MainPage : UserControl
	{
		MapLayer pinLayer = new MapLayer();

		public MainPage()
		{
			InitializeComponent();

			this.ViewModel = new MainWindowViewModel();
			this.ViewModel.PropertyChanged += ViewModel_PropertyChanged;

			this.mapMain.Children.Add(pinLayer);
	
			this.PopulatePushPins();

			//Uri serviceUri = new Uri("http://silverlightmaps.org/services/geolocation_service.php");

			//// Create a web client to load the document
			//WebClient client = new WebClient();
			//client.OpenReadCompleted += (sender, e) =>
			//{
			//    if (e.Error != null)
			//    {
			//        // Do nothing
			//        return;
			//    }
			//    using (Stream s = e.Result)
			//    {
			//        // Load the XML stream into the XDocument
			//        XDocument doc = XDocument.Load(s);
			//        XElement location = doc.Root;

			//        // Grab the latitude and longitude
			//        String latitude = location.Element("latitude").Value;
			//        String longitude = location.Element("longitude").Value;

			//        // Center the map over the coordinates

			//        Location mapCenter = new Location(Double.Parse(latitude), Double.Parse(longitude));

			//        this.mapMain.Center = mapCenter;

			//TODO	this.ViewModel.CurrentLocation = mapCenter;			

			//        //this.PopulatePushPins();
			//    }
			//};
			
			//client.OpenReadAsync(serviceUri);
		}

		public MainWindowViewModel ViewModel
		{
			get
			{
				return (MainWindowViewModel)this.DataContext;
			}
			set
			{
				this.DataContext = value;
			}
		}

		void ViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			switch (e.PropertyName)
			{
				case "MapItems":
					this.PopulatePushPins();
					break;				
			}
		}

		private void PopulatePushPins()
		{
			//Add shape layer to map

			foreach (CustomPushpin item in pinLayer.Children)
			{
				item.Disappear();
			} 

			/**************************************
			 * Example of Icon Pushpin
			 **************************************/

			foreach (var item in this.ViewModel.MapItems)
			{
				//Create custom pushpin
				//CustomPushpin pin = new CustomPushpin()
				//{
				//    IconSpecification = iconSpec,
				//    Location = item.GeoLocation
				//};

				////Add pushpin to layer
				//pinLayer.AddChild(pin);


				/**************************************
				 * Example of Circle Pushpin
				 **************************************/

				//Create a custom pushpin specification
				CustomIconSpecification iconSpec2 = new CustomIconSpecification()
				{
					Icon = PushpinTools.CreateImagePushpin(item.ImageURI, 60, 60, new Point(-10, -10)),
					Width = 20,
					Height = 20,
					IconOffset = new Point(-10, -10),
					TextContent = "Deals",
					TextOffet = new Point(-10, -10)

					//Icon = PushpinTools.CreateCirclePushpin(10, new SolidColorBrush(Colors.Red), new SolidColorBrush(Colors.Blue)),
					//Width = 20,
					//Height = 20,
					//IconOffset = new Point(-10, -10),
					//TextContent = "1",
					//TextOffet = new Point(-10, -10)
				};

				//Create custom pushpin
				CustomPushpin circlePin = new CustomPushpin()
				{
					IconSpecification = iconSpec2,
					Location = item.GeoLocation
				};

				circlePin.DataContext = item;

				circlePin.MouseLeftButtonDown += new System.Windows.Input.MouseButtonEventHandler(circlePin_MouseLeftButtonDown);

				//Add pushpin to layer
				pinLayer.AddChild(circlePin);
			}

			if (this.ViewModel.MapItems.Count > 0)
				this.mapMain.Center = this.ViewModel.MapItems[0].GeoLocation;
		}

		void circlePin_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			//LandMark landMark = 
			//    (Cto.Silverilght.ViewModels.MainWindowViewModel.LandMark)((CustomPushpin)sender).DataContext;
			
			this.markDetailsView.DataContext = ((CustomPushpin)sender).DataContext;
			this.markDetailsView.Visibility = Visibility.Visible;
		}

		private void HyperlinkButton_Click(object sender, RoutedEventArgs e)
		{
			Cto.Silverilght.ViewModels.MainWindowViewModel.City city = (Cto.Silverilght.ViewModels.MainWindowViewModel.City)((System.Windows.Controls.HyperlinkButton)sender).DataContext;

			this.ViewModel.CurrentCity = city;

			this.ViewModel.MapLocation = city.Location;

			this.ViewModel.GetMarksByLocationCommand.Execute(null);
		}

		private void mapMain_ViewChangeEnd(object sender, MapEventArgs e)
		{
			this.ViewModel.MapLocation = mapMain.Center;

			this.ViewModel.IsRefreshNeeded = true;
		}
	}
}
